Implement the bubble sort using python

----------------------------------------------------------------

def sort_bubblesort(my_list):

    for pos_upper in xrange(len(my_list)-1,0,-1):
        for i in xrange(pos_upper):
            if my_list[i] > my_list[i+1]:
                my_list[i], my_list[i+1] = my_list[i+1], my_list[i]
                print "pos_upper: " + str(pos_upper) + " i: " + str(i) + " my_list: " + str(my_list)
    return my_list

if __name__ == "__main__":

    my_list = [54,26,93,17,77,31,44,55,20]
    print my_list
    print sort_bubblesort(my_list)


#---------------------------------------------------------------------------------------#
#scifiswapnil@scifiswapnil-virtual-PC:~$ python bubble_sort.py 
#[54, 26, 93, 17, 77, 31, 44, 55, 20]
#pos_upper: 8 i: 0 my_list: [26, 54, 93, 17, 77, 31, 44, 55, 20]
#pos_upper: 8 i: 2 my_list: [26, 54, 17, 93, 77, 31, 44, 55, 20]
#pos_upper: 8 i: 3 my_list: [26, 54, 17, 77, 93, 31, 44, 55, 20]
#pos_upper: 8 i: 4 my_list: [26, 54, 17, 77, 31, 93, 44, 55, 20]
#pos_upper: 8 i: 5 my_list: [26, 54, 17, 77, 31, 44, 93, 55, 20]
#pos_upper: 8 i: 6 my_list: [26, 54, 17, 77, 31, 44, 55, 93, 20]
#pos_upper: 8 i: 7 my_list: [26, 54, 17, 77, 31, 44, 55, 20, 93]
#pos_upper: 7 i: 1 my_list: [26, 17, 54, 77, 31, 44, 55, 20, 93]
#pos_upper: 7 i: 3 my_list: [26, 17, 54, 31, 77, 44, 55, 20, 93]
#pos_upper: 7 i: 4 my_list: [26, 17, 54, 31, 44, 77, 55, 20, 93]
#pos_upper: 7 i: 5 my_list: [26, 17, 54, 31, 44, 55, 77, 20, 93]
#pos_upper: 7 i: 6 my_list: [26, 17, 54, 31, 44, 55, 20, 77, 93]
#pos_upper: 6 i: 0 my_list: [17, 26, 54, 31, 44, 55, 20, 77, 93]
#pos_upper: 6 i: 2 my_list: [17, 26, 31, 54, 44, 55, 20, 77, 93]
#pos_upper: 6 i: 3 my_list: [17, 26, 31, 44, 54, 55, 20, 77, 93]
#pos_upper: 6 i: 5 my_list: [17, 26, 31, 44, 54, 20, 55, 77, 93]
#pos_upper: 5 i: 4 my_list: [17, 26, 31, 44, 20, 54, 55, 77, 93]
#pos_upper: 4 i: 3 my_list: [17, 26, 31, 20, 44, 54, 55, 77, 93]
#pos_upper: 3 i: 2 my_list: [17, 26, 20, 31, 44, 54, 55, 77, 93]
#pos_upper: 2 i: 1 my_list: [17, 20, 26, 31, 44, 54, 55, 77, 93]
#[17, 20, 26, 31, 44, 54, 55, 77, 93]
#scifiswapnil@scifiswapnil-virtual-g4-PC:~$ 
#---------------------------------------------------------------------------------------#
