
import bitwise
import booth
from tkinter import *
import json
import xml.etree.ElementTree as ET
import urllib.request as r

global a,b,lab,lab1,lab2,lab3
def client_exit():
    exit()

def restart():
    global lab,lab1,lab2,lab3
    lab.place_forget()
    lab1.place_forget()
    lab2.place_forget()
    lab3.place_forget()



def up_json():
    global a,lab
    with open("input.json") as data_file:
        data_json = json.load(data_file)
        a = int(data_json["Number"])
        lab = Label(root,text= "Uploaded !!\nNo: "+str(a))
        lab.place(x = 220, y=0)


def up_xml():
    global b,lab1
    tree= ET.parse('input.xml')
    parent = tree.getroot()
    # root = ET.fromstring('data')
    b = int(parent[0].text)
    lab1 = Label(root,text= "Uploaded !!\nNo: "+str(b))
    lab1.place(x = 220, y=50)

def mul():
    global a,b,lab3,lab2
    bin,dec  = booth.booth(a,b)
    lab2 = Label(root,text= "Binary: "+str(bin))
    lab2.place(x = 100,y=200)
    lab3 = Label(root,text= "Decimal: "+str(dec))
    lab3.place(x = 100,y=220)


# Creating window
root = Tk()
root.geometry("400x300")
root.title("Booth's Multilication")

# Creating Menu
menu = Menu(root)
root.config(menu=menu)
file = Menu(menu)
file.add_command(label="Refresh", command=restart,)
file.add_command(label="Exit", command=client_exit)
menu.add_cascade(label="File", menu=file)

# Creating buttons
jso = Button(root, text="Upload no from json",width = 20, height= 2, command = up_json)
jso.place(x =50,y=0 )

jso_ou = str()


xm = Button(root,text="Upload from xml",width = 20, height= 2, command = up_xml)
xm.place(x =50,y=50 )


add =Button(root,text= "Perform booth's multiplication",width = 40, height= 3,command = mul)
add.place(x =50,y=130 )


#mainloop
root.mainloop()


